package com.cg.banking.services;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServices;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
public class BankingServicesImpl implements BankingServices {

	private BankingDAOServices bankDao;
	
	
	public BankingServicesImpl() {
		bankDao = new BankingDAOServicesImpl();
	}
	public BankingServicesImpl(BankingDAOServices mockDaoServices) {
		bankDao = mockDaoServices;
	}
	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String emailId, String panCard,
			int homeAddressPinCode, String homeAddressCity, String homeAddressState, int localAddressPinCode,
			String localAddressCity, String localAddressState) throws BankingServicesDownException {
		
		return 0;
	}


	@Override
	public float depositAmount(int customerId,  int accountNo, float amount)
			throws CustomerNotFoundException, AccountNotFoundException,
			BankingServicesDownException {
		Account acct =null;
	if(bankDao.getCustomer(customerId) != null){		
		 acct = bankDao.getAccount(customerId, accountNo);
		if (acct != null) {
			System.out.println("Balance "
					+ (acct.getAccountBalance() + amount));
			acct.setAccountBalance(acct.getAccountBalance() + amount);
			Transaction trans = new Transaction();
			trans.setAmount(amount);
			trans.setTransactionType("Deposit");

			if( bankDao.insertTransaction(customerId, accountNo, trans))
				return acct.getAccountBalance();			
		} else
			throw new AccountNotFoundException("Account not found!");
	   }
		else
			throw new CustomerNotFoundException("Customer Not Found");
	return acct.getAccountBalance();
	}

	@Override
	public float withdrawAmount(int customerId, int accountNo, float amount, int pinNumber)
			throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean fundTransfer(int customerIdTo, int accountNoTo, int customerIdFrom, int accountNoFrom,
			float transferAmount, int pinNumber) throws InsufficientAmountException, CustomerNotFoundException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Customer getCustomerDetails(int customerId) throws CustomerNotFoundException, BankingServicesDownException {
		
		return bankDao.getCustomer(customerId);
	}

	@Override
	public Account getAccountDetails(int customerId, int accountNo)
			throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		return bankDao.getAccount(customerId, accountNo);
	}

	@Override
	public int generateCustomerAccountNewPin(int customerId, int accountNo)
			throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean changeCustomerAccountPin(int customerId, int accountNo, int oldPinNumber, int newPinNumber)
			throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		if(bankDao.getCustomer(customerId)!= null){
			Account acct = bankDao.getAccount(customerId, accountNo);
			if (acct != null) {
				if (oldPinNumber == acct.getPinNumber()) {
					acct.setPinNumber(newPinNumber);
					if (bankDao.updateAccount(customerId, acct))
						return true;
				} else
					throw new InvalidPinNumberException(
							"Old pin is incorrect!! Try Again");
			} else
				throw new AccountNotFoundException("Account not found!!");
			return false;
		}
		else
			throw new CustomerNotFoundException();
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BankingServicesDownException {
		
		return bankDao.getCustomers();
	}

	@Override
	public List<Account> getCustomerAllAccountDetails(int customerId)
			throws BankingServicesDownException, CustomerNotFoundException {
		if(bankDao.getCustomer(customerId)!= null){
			return bankDao.getAccounts(customerId);
		}
		else
			throw new CustomerNotFoundException();
	}

	@Override
	public List<Transaction> getAccountAllTransaction(int customerId, int accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		if(bankDao.getAccount(customerId, accountNo)!=null){
			return bankDao.getTransaction(accountNo);
		}
		else
			throw new AccountNotFoundException();
		
	}

	@Override
	public String getCustomeAccountStatus(int customerId, int accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		if(bankDao.getCustomer(customerId)!= null){
			if(bankDao.getAccount(customerId, accountNo)!=null){
				return bankDao.getAccount(customerId, accountNo).getStatus();
			}
			else
				throw new AccountNotFoundException();
		}
		else
			throw new CustomerNotFoundException();
	}
	@Override
	public int openAccount(int customerId, int accountBalance,
			String accountType) throws InvalidAmountException,
			CustomerNotFoundException, InvalidAccountTypeException,
			BankingServicesDownException {
		return 0;
	}

	
	

}
