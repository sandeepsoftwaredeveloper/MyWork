package com.cg.banking.test;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.AfterClass;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServices;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class BankingServicesTestUsingMokito {

	private static BankingServices bankServices;
	private static BankingDAOServices mockDaoServices;

	@BeforeClass
	public static void setUpBankingServices(){
		mockDaoServices= Mockito.mock(BankingDAOServices.class);
		bankServices = new BankingServicesImpl(mockDaoServices);
	}

	@Before
	public void setUpBankData() throws SQLException{

		ArrayList<Transaction> transactions = new ArrayList<Transaction>();
		Transaction transact1 = new Transaction(454445,1000,"Deposit");
		Transaction transact2 = new Transaction(454446,1000,"Deposit");
		Transaction transact3 = new Transaction(454447,1000,"Deposit");
		
		transactions.add(transact1);
		transactions.add(transact2);
		transactions.add(transact3);
		
		ArrayList<Account> accounts = new ArrayList<>();
		Account account1 = new Account(5000001,"SAVINGS", 4000, 1111, "OPEN", 0,transact1 );
		Account account2 =  new Account(5444676,"SAVINGS", 4000, 1111, "Blocked", 0,transact2);
		Account account3 = new Account(544999,"SAVINGS", 4000, 1234, "OPEN", 0, transact3);
		Account account4= new Account("SAVINGS",5000, 4567, "OPEN", 0, null);
		accounts.add(account1);
		accounts.add(account2);
		accounts.add(account3);
		
		Customer customer1 =  new Customer(1000, "Shubham", "Gupta", "shubahm.gupta@cg.com", "ABDW4551", "123345", new Address(2545211, "Agra", "UP"),account1 );
		Customer customer2 = new Customer(1001, "Mohini", "Rai", "mohini.rai@cg.com", "ABDW4551", "123345", new Address(2545211, "Agra", "UP"), account2);
		Customer customer3 =  new Customer(1002, "ram", "Rai", "ram.rai@cg.com", "ABDW4551", "123345", new Address(2545211, "Agra", "UP"), account3);
		Customer customer4 = new Customer("Jugnu", "Singh", "jugnu.singh@cg.com", "AHS7896", "123456", new Address(2548414, "Lucknow", "UP"), account3);
		
		ArrayList<Customer> customers = new ArrayList<>();
		customers.add(customer1);
		customers.add(customer2);
		customers.add(customer3);
		
		
		Mockito.when(mockDaoServices.getCustomer(1000)).thenReturn(customer1);
		Mockito.when(mockDaoServices.getCustomer(1001)).thenReturn(customer2);
		Mockito.when(mockDaoServices.getCustomer(1002)).thenReturn(customer3);
		Mockito.when(mockDaoServices.getCustomer(1455)).thenReturn(null);
		Mockito.when(mockDaoServices.getCustomers()).thenReturn(customers);
		
		Mockito.when(mockDaoServices.insertCustomer(customer4)).thenReturn(1003);
		
		Mockito.when(mockDaoServices.getAccount(1000, 5000001)).thenReturn(account1);
		Mockito.when(mockDaoServices.getAccount(1000, 5000045)).thenReturn(null);
		Mockito.when(mockDaoServices.getAccount(1023, 5000001)).thenReturn(null);
		
		Mockito.when(mockDaoServices.getAccounts(1000)).thenReturn(new ArrayList<>(customers.get(1).getAccounts().values()) );
		Mockito.when(mockDaoServices.getAccounts(1032)).thenReturn(null);
		
		Mockito.when(mockDaoServices.generatePin(account1)).thenReturn(1234);
		Mockito.when(mockDaoServices.deleteAccount(1001, 5444676)).thenReturn(true);
		Mockito.when(mockDaoServices.deleteAccount(1533, 5444676)).thenReturn(false);
		Mockito.when(mockDaoServices.deleteAccount(1001, 534543)).thenReturn(false);
		Mockito.when(mockDaoServices.deleteCustomer(1001)).thenReturn(true);
		Mockito.when(mockDaoServices.deleteCustomer(1054)).thenReturn(false);
		Mockito.when(mockDaoServices.insertAccount(account4)).thenReturn(664533);
		Mockito.when(mockDaoServices.updateAccount(1000, account1)).thenReturn(true);
		Mockito.when(mockDaoServices.updateAccount(1043, account1)).thenReturn(false);
		Mockito.when(mockDaoServices.updateAccount(1000, account3)).thenReturn(false);




		//Mockito.when(mockDaoServices.getTransaction(5000001)).thenReturn(new ArrayList<>(customers.get(1).getAccounts().get(account1).getTransactions().values()));
	
		
		
		
	}

	@Test(expected=CustomerNotFoundException.class)
	public void testGetCustomerDetailsForInvalidData() throws CustomerNotFoundException, BankingServicesDownException{
		bankServices.getCustomerDetails(35667);
	}

	@Test
	public void testGetCustomerDetailsForValidData() throws CustomerNotFoundException, BankingServicesDownException{
		Customer actualCustomer =bankServices.getCustomerDetails(1000);
		Customer expectedCustomer= new Customer(1000, "Shubham", "Gupta", "shubahm.gupta@cg.com", "ABDW4551", "123345", new Address(2545211, "Agra", "UP"), new Account(5000001,"SAVINGS", 4000, 1111, "OPEN", 0, new Transaction(454445,1000,"Deposit")));
		assertEquals(expectedCustomer,actualCustomer);
	}

	@Test(expected=CustomerNotFoundException.class)
	public void testGetAccountDetailsForInvalidCustomerId() throws CustomerNotFoundException, BankingServicesDownException, AccountNotFoundException{
		bankServices.getAccountDetails(42344, 56456);		
	}

	@Test(expected=AccountNotFoundException.class)
	public void testGetAccountDetailsForInvalidAccountNo() throws CustomerNotFoundException, BankingServicesDownException, AccountNotFoundException{
		bankServices.getAccountDetails(1000, 56456);		
	}	

	@Test
	public void testGetAccountDetailsForValidData() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException{
		Account expectedAccount= new Account(5000001,"SAVINGS", 4000, 1111, "OPEN", 0, new Transaction(454445,1000,"Deposit"));
		Account actualAccount= bankServices.getAccountDetails(1000, 5000001);
		assertEquals(expectedAccount, actualAccount);
	}

	@Test(expected=AccountNotFoundException.class)
	public void testGetAccountAllTransactionForInvalidData() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		bankServices.getAccountAllTransaction(1000, 31314);
	}

	@Test
	public void testGetAllCustomerDetails() throws BankingServicesDownException{
		List<Customer> expectedCustomers = new ArrayList<>(BankingDAOServicesImpl.customer.values());
		List<Customer> actualCustomers = bankServices.getAllCustomerDetails();
		assertEquals(expectedCustomers, actualCustomers);
	}

	@Test(expected=CustomerNotFoundException.class)
	public void testGetCustomerAccountStatusForInvalidCustomerId() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		bankServices.getCustomeAccountStatus(32133, 534535);

	}

	@Test(expected=AccountNotFoundException.class)
	public void testGetCustomerAccountStatusForInvalidAccountNo() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		bankServices.getCustomeAccountStatus(1000, 534535);

	}

	@Test
	public void testGetCustomerAccountStatusForValidData() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		String actualStatus= "Open";
		String expectedStatus= bankServices.getCustomeAccountStatus(1000, 5000001);
		assertEquals(actualStatus, expectedStatus);
	}

	@Test(expected=CustomerNotFoundException.class)
	public void testGetCustomerAllAccountForInvalidData() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		bankServices.getCustomerAllAccountDetails(1000);
	}

	@Test
	public void testGetCustomerAllAccountForValidData() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		ArrayList<Account> acctualAccounts = new ArrayList<>();
		acctualAccounts.add(new Account(5000001,"SAVINGS", 4000, 1111, "OPEN", 0, new Transaction(454445,1000,"Deposit")));
		List<Account> expectedAccounts = bankServices.getCustomerAllAccountDetails(1000);
		assertEquals(acctualAccounts, expectedAccounts);
	}

	@Test
	public void testAcceptCustomerDetailsForValidData() throws BankingServicesDownException{
		int expectedCustomerId = 1003;
		int actualCustomerId = bankServices.acceptCustomerDetails("Jugnu", "Singh", "jugnu.singh@cg.com", "FSF4566", 4444014, "Lucknow", "UP", 100110, "Pune", "Maharastra");
		assertEquals(expectedCustomerId, actualCustomerId);
	}



	@Test(expected=CustomerNotFoundException.class)
	public void testChangeCustomerAccountPinForInvalidCustomerId() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		bankServices.changeCustomerAccountPin(2133, 2343244, 4333, 6789);

	}

	@Test(expected=AccountNotFoundException.class)
	public void testChangeCustomerAccountPinForInvalidAccountNo() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		bankServices.changeCustomerAccountPin(1000, 2343244, 4333, 6789);
	}
	@Test(expected=InvalidPinNumberException.class)
	public void testChangeCustomerAccountPinForInvalidOldPin() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		bankServices.changeCustomerAccountPin(1000, 5000001, 4333, 6789);
	}

	/*@Test(expected= AccountBlockedException.class)
	public void testChangeCustomerAccountPinForBlockedAccount() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		bankServices.changeCustomerAccountPin(1001, 5444676, 1111, 6789);
	}*/
	@Test
	public void testChangeCustomerAccountPinForValidData() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		boolean expectedResult= true;
		boolean actualResult= bankServices.changeCustomerAccountPin(1000, 5000001, 1111, 6789);
		assertEquals(expectedResult, actualResult);
	}

	/*@Test(expected= AccountBlockedException.class)
	public void testDepositAmountForBlockedAccount() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		bankServices.depositAmount(1076, 5444676, 10000);
	}*/
	@Test(expected=CustomerNotFoundException.class)
	public void testDepositAmountForInvalidCustomerId() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		bankServices.depositAmount(10070, 8767565, 10000);

	}
	@Test(expected=AccountNotFoundException.class)
	public void testDepositAmountForInvalidAccountNo() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		bankServices.depositAmount(1001, 5000001, 10000);
	}

	@Test
	public void testDepositAmountForValidData() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		Float expectedBalance= 15000f;
		Float actualBalance=bankServices.depositAmount(1000, 5000001, 10000);
		assertEquals(expectedBalance, actualBalance);
	}


	@Test(expected= AccountBlockedException.class)
	public void testFundTransferForcustomerIdToBlockedAccount() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		bankServices.fundTransfer(1002, 5444676, 1000, 756755, 40000, 1234);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testFundTransferForInvalidCustomerIdTo() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		bankServices.fundTransfer(1089, 5444676, 1000, 756755, 40000, 1234);

	}

	@Test(expected= AccountBlockedException.class)
	public void testFundTransferForcustomerIdFromBlockedAccount() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		bankServices.fundTransfer(1000, 756755, 1002, 5444676, 40000, 1234);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testFundTransferForInvalidCustomerIdFrom() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		bankServices.fundTransfer(1000, 5444676, 1098, 756755, 40000, 1234);

	}
	@Test(expected=AccountNotFoundException.class)
	public void testFundTransferForInvalidAccountNoTo() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		bankServices.fundTransfer(1000, 5444654, 1002, 756755, 40000, 1234);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testFundTransferForInvalidAccountNoFrom() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		bankServices.fundTransfer(1000, 5000001, 1002, 756755, 40000, 1234);
	}

	@Test(expected=InvalidPinNumberException.class)
	public void testFundTransferForInvalidPinNo() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		bankServices.fundTransfer(1000, 5000001, 1002, 544999, 40000, 8765);
	}

	@Test(expected=InsufficientAmountException.class)
	public void testFundTransferForInsufficientAmount() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		bankServices.fundTransfer(1000, 5000001, 1002, 544999, 40000, 1234);
	}

	@Test
	public void testFundTransferForValidData() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		boolean expectedResult= true;
		boolean actualResult=bankServices.fundTransfer(1000, 5000001, 1002, 544999, 2000, 1234);
		assertEquals(expectedResult, actualResult);
	}


	@Test(expected=CustomerNotFoundException.class)
	public void testGenerateCustomerAccountNewPinForInvalidCustomerId() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		bankServices.generateCustomerAccountNewPin(4242, 54444446);

	}

	@Test(expected=AccountNotFoundException.class)
	public void testGenerateCustomerAccountNewPinForInvalidAccountNo() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		bankServices.generateCustomerAccountNewPin(1000, 54455246);
	}
	@Test
	public void testGenerateCustomerAccountNewPinForValidData() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		int actualPin =bankServices.generateCustomerAccountNewPin(1000, 54455246);
		int count= 0;
		while(actualPin!=0){
			actualPin= actualPin/10;
			count++;
		}
		assertTrue(count == 4);
	}
	
	@Test(expected= AccountBlockedException.class)
	public void testWithdrawAmountForBlockedAccount() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		bankServices.withdrawAmount(1001, 5444676, 500, 3212);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testWithdrawAmountForInvalidCustomerId() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		bankServices.withdrawAmount(1043, 5444676, 500, 3212);

	}
	@Test(expected=AccountNotFoundException.class)
	public void testWithdrawAmountForInvalidAccountNo() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		bankServices.withdrawAmount(1000, 5444996, 500, 3212);
	}

	@Test
	public void testWithdrawAmountForValidData() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		Float expectedBalance= 3500f;
		Float actualBalance=bankServices.withdrawAmount(1000, 5000001, 500, 1111);
		assertEquals(expectedBalance, actualBalance);
	}
	
	@Test(expected=InvalidPinNumberException.class)
	public void testWithdrawAmountForInvalidPinNo() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		bankServices.withdrawAmount(1000, 5000001, 500, 3212);
	}

	@Test(expected=InsufficientAmountException.class)
	public void testWithdrawAmountForInsufficientAmount() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		bankServices.withdrawAmount(1000, 5000001, 50000, 1111);
	}
	
	@Test(expected=CustomerNotFoundException.class)
	public void testOpenAccountForInvalidCustomerId() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		bankServices.openAccount(1254, 15154, "SAVINGS");
	}
	
	@Test(expected=InvalidAmountException.class)
	public void testOpenAccountForInvalidAmount() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		bankServices.openAccount(1000, -54, "SAVINGS");
	}
	@Test(expected=InvalidAccountTypeException.class)
	public void testOpenAccountForInvalidAccountType() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		bankServices.openAccount(1000, 15154, "NULL");
	}
	
	@Test
	public void testOpenAccountForValidData() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		int expectedResult = 56768;
		int actualResult = bankServices.openAccount(1000, 34234, "SAVINGS");
		assertEquals(expectedResult, actualResult);
		
	}
	
	@After
	public void tearDownBankData(){
		BankingDAOServicesImpl.customer.clear();
		BankingDAOServicesImpl.CUSTOMER_ID_COUNTER = 1000;
	}

	@AfterClass
	public static void tearDownBankingServices(){
		bankServices= null;
	}

}
