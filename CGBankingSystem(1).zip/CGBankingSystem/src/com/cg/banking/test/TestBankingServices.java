package com.cg.banking.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mock;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class TestBankingServices {

	private static BankingServices bankServices;

	@BeforeClass
	public static void setUpBankingServices(){
		bankServices = new BankingServicesImpl();
	}

	@Before
	public void setUpBankData(){
		BankingDAOServicesImpl.customer.put(1000, new Customer(1000, "Shubham", "Gupta", "shubahm.gupta@cg.com", "ABDW4551", "123345", new Address(2545211, "Agra", "UP"), new Account(5444446,"SAVINGS", 4000, 1111, "OPEN", 0, new Transaction(454445,1000,"Deposit"))));
		BankingDAOServicesImpl.customer.put(1001, new Customer(1001, "Mohini", "Rai", "mohini.rai@cg.com", "ABDW4551", "123345", new Address(2545211, "Agra", "UP"), new Account(5444676,"SAVINGS", 4000, 1111, "Blocked", 0, new Transaction(454446,1000,"Deposit"))));
		BankingDAOServicesImpl.customer.put(1001, new Customer(1002, "ram", "Rai", "ram.rai@cg.com", "ABDW4551", "123345", new Address(2545211, "Agra", "UP"), new Account(544999,"SAVINGS", 4000, 1234, "OPEN", 0, new Transaction(454447,1000,"Deposit"))));
		BankingDAOServicesImpl.CUSTOMER_ID_COUNTER = 1002;
	}

	@Test(expected=CustomerNotFoundException.class)
	public void testGetCustomerDetailsForInvalidData() throws CustomerNotFoundException, BankingServicesDownException{
		bankServices.getCustomerDetails(35667);
	}

	@Test
	public void testGetCustomerDetailsForValidData() throws CustomerNotFoundException, BankingServicesDownException{
		Customer actualCustomer =bankServices.getCustomerDetails(1000);
		Customer expectedCustomer= new Customer(1000, "Shubham", "Gupta", "shubahm.gupta@cg.com", "ABDW4551", "123345", new Address(2545211, "Agra", "UP"), new Account(5444446,"SAVINGS", 4000, 1111, "OPEN", 0, new Transaction(454445,1000,"Deposit")));
		assertEquals(expectedCustomer,actualCustomer);
	}

	@Test(expected=CustomerNotFoundException.class)
	public void testGetAccountDetailsForInvalidCustomerId() throws CustomerNotFoundException, BankingServicesDownException, AccountNotFoundException{
		bankServices.getAccountDetails(42344, 56456);		
	}

	@Test(expected=AccountNotFoundException.class)
	public void testGetAccountDetailsForInvalidAccountNo() throws CustomerNotFoundException, BankingServicesDownException, AccountNotFoundException{
		bankServices.getAccountDetails(1000, 56456);		
	}	

	@Test
	public void testGetAccountDetailsForValidData() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException{
		Account expectedAccount= new Account(5444446,"SAVINGS", 4000, 1111, "OPEN", 0, new Transaction(454445,1000,"Deposit"));
		Account actualAccount= bankServices.getAccountDetails(1000, 5444446);
		assertEquals(expectedAccount, actualAccount);
	}

	@Test(expected=AccountNotFoundException.class)
	public void testGetAccountAllTransactionForInvalidData() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		bankServices.getAccountAllTransaction(1000, 31314);
	}

	@Test
	public void testGetAllCustomerDetails() throws BankingServicesDownException{
		List<Customer> expectedCustomers = new ArrayList<>(BankingDAOServicesImpl.customer.values());
		List<Customer> actualCustomers = bankServices.getAllCustomerDetails();
		assertEquals(expectedCustomers, actualCustomers);
	}

	@Test(expected=CustomerNotFoundException.class)
	public void testGetCustomerAccountStatusForInvalidCustomerId() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		bankServices.getCustomeAccountStatus(32133, 534535);

	}

	@Test(expected=AccountNotFoundException.class)
	public void testGetCustomerAccountStatusForInvalidAccountNo() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		bankServices.getCustomeAccountStatus(1000, 534535);

	}

	@Test
	public void testGetCustomerAccountStatusForValidData() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		String actualStatus= "Open";
		String expectedStatus= bankServices.getCustomeAccountStatus(1000, 5444446);
		assertEquals(actualStatus, expectedStatus);
	}

	@Test(expected=CustomerNotFoundException.class)
	public void testGetCustomerAllAccountForInvalidData() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		bankServices.getCustomerAllAccountDetails(1000);
	}

	@Test
	public void testGetCustomerAllAccountForValidData() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		List<Account> acctualAccounts = new ArrayList<>();
		acctualAccounts.add(new Account(5444446,"SAVINGS", 4000, 1111, "OPEN", 0, new Transaction(454445,1000,"Deposit")));
		List<Account> expectedAccounts = bankServices.getCustomerAllAccountDetails(1000);
		assertEquals(acctualAccounts, expectedAccounts);
	}

	@Test
	public void testAcceptCustomerDetailsForValidData() throws BankingServicesDownException{
		int expectedCustomerId = 1003;
		int actualCustomerId = bankServices.acceptCustomerDetails("Jugnu", "Singh", "jugnu.singh@cg.com", "FSF4566", 4444014, "Lucknow", "UP", 100110, "Pune", "Maharastra");
		assertEquals(expectedCustomerId, actualCustomerId);
	}



	@Test(expected=CustomerNotFoundException.class)
	public void testChangeCustomerAccountPinForInvalidCustomerId() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		bankServices.changeCustomerAccountPin(2133, 2343244, 4333, 6789);

	}

	@Test(expected=AccountNotFoundException.class)
	public void testChangeCustomerAccountPinForInvalidAccountNo() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		bankServices.changeCustomerAccountPin(1000, 2343244, 4333, 6789);
	}
	@Test(expected=InvalidPinNumberException.class)
	public void testChangeCustomerAccountPinForInvalidOldPin() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		bankServices.changeCustomerAccountPin(1000, 5444446, 4333, 6789);
	}

	@Test(expected= AccountBlockedException.class)
	public void testChangeCustomerAccountPinForBlockedAccount() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		bankServices.changeCustomerAccountPin(1001, 5444676, 1111, 6789);
	}
	@Test
	public void testChangeCustomerAccountPinForValidData() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		boolean expectedResult= true;
		boolean actualResult= bankServices.changeCustomerAccountPin(1000, 5444446, 1111, 6789);
		assertEquals(expectedResult, actualResult);
	}

	@Test(expected= AccountBlockedException.class)
	public void testDepositAmountForBlockedAccount() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		bankServices.depositAmount(1076, 5444676, 10000);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testDepositAmountForInvalidCustomerId() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		bankServices.depositAmount(1000, 8767565, 10000);

	}
	@Test(expected=AccountNotFoundException.class)
	public void testDepositAmountForInvalidAccountNo() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		bankServices.depositAmount(1001, 5444446, 10000);
	}

	@Test
	public void testDepositAmountForValidData() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		Float expectedBalance= 15000f;
		Float actualBalance=bankServices.depositAmount(1000, 5444446, 10000);
		assertEquals(expectedBalance, actualBalance);
	}


	@Test(expected= AccountBlockedException.class)
	public void testFundTransferForcustomerIdToBlockedAccount() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		bankServices.fundTransfer(1002, 5444676, 1000, 756755, 40000, 1234);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testFundTransferForInvalidCustomerIdTo() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		bankServices.fundTransfer(1089, 5444676, 1000, 756755, 40000, 1234);

	}

	@Test(expected= AccountBlockedException.class)
	public void testFundTransferForcustomerIdFromBlockedAccount() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		bankServices.fundTransfer(1000, 756755, 1002, 5444676, 40000, 1234);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testFundTransferForInvalidCustomerIdFrom() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		bankServices.fundTransfer(1000, 5444676, 1098, 756755, 40000, 1234);

	}
	@Test(expected=AccountNotFoundException.class)
	public void testFundTransferForInvalidAccountNoTo() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		bankServices.fundTransfer(1000, 5444654, 1002, 756755, 40000, 1234);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testFundTransferForInvalidAccountNoFrom() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		bankServices.fundTransfer(1000, 5444446, 1002, 756755, 40000, 1234);
	}

	@Test(expected=InvalidPinNumberException.class)
	public void testFundTransferForInvalidPinNo() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		bankServices.fundTransfer(1000, 5444446, 1002, 544999, 40000, 8765);
	}

	@Test(expected=InsufficientAmountException.class)
	public void testFundTransferForInsufficientAmount() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		bankServices.fundTransfer(1000, 5444446, 1002, 544999, 40000, 1234);
	}

	@Test
	public void testFundTransferForValidData() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		boolean expectedResult= true;
		boolean actualResult=bankServices.fundTransfer(1000, 5444446, 1002, 544999, 2000, 1234);
		assertEquals(expectedResult, actualResult);
	}


	@Test(expected=CustomerNotFoundException.class)
	public void testGenerateCustomerAccountNewPinForInvalidCustomerId() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		bankServices.generateCustomerAccountNewPin(4242, 54444446);

	}

	@Test(expected=AccountNotFoundException.class)
	public void testGenerateCustomerAccountNewPinForInvalidAccountNo() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		bankServices.generateCustomerAccountNewPin(1000, 54455246);
	}
	@Test
	public void testGenerateCustomerAccountNewPinForValidData() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		int actualPin =bankServices.generateCustomerAccountNewPin(1000, 54455246);
		int count= 0;
		while(actualPin!=0){
			actualPin= actualPin/10;
			count++;
		}
		assertTrue(count == 4);
	}
	
	@Test(expected= AccountBlockedException.class)
	public void testWithdrawAmountForBlockedAccount() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		bankServices.withdrawAmount(1001, 5444676, 500, 3212);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testWithdrawAmountForInvalidCustomerId() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		bankServices.withdrawAmount(1043, 5444676, 500, 3212);

	}
	@Test(expected=AccountNotFoundException.class)
	public void testWithdrawAmountForInvalidAccountNo() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		bankServices.withdrawAmount(1000, 5444996, 500, 3212);
	}

	@Test
	public void testWithdrawAmountForValidData() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		Float expectedBalance= 3500f;
		Float actualBalance=bankServices.withdrawAmount(1000, 5444446, 500, 1111);
		assertEquals(expectedBalance, actualBalance);
	}
	
	@Test(expected=InvalidPinNumberException.class)
	public void testWithdrawAmountForInvalidPinNo() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		bankServices.withdrawAmount(1000, 5444446, 500, 3212);
	}

	@Test(expected=InsufficientAmountException.class)
	public void testWithdrawAmountForInsufficientAmount() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException, InsufficientAmountException{
		bankServices.withdrawAmount(1000, 5444446, 50000, 1111);
	}
	
	@Test(expected=CustomerNotFoundException.class)
	public void testOpenAccountForInvalidCustomerId() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		bankServices.openAccount(1254, 15154, "SAVINGS");
	}
	
	@Test(expected=InvalidAmountException.class)
	public void testOpenAccountForInvalidAmount() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		bankServices.openAccount(1000, -54, "SAVINGS");
	}
	@Test(expected=InvalidAccountTypeException.class)
	public void testOpenAccountForInvalidAccountType() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		bankServices.openAccount(1000, 15154, "NULL");
	}
	
	
	
	@Test
	public void testOpenAccountForValidData() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		int expectedResult = 56768;
		int actualResult = bankServices.openAccount(1000, 34234, "SAVINGS");
		assertEquals(expectedResult, actualResult);
		
	}
	
	@After
	public void tearDownBankData(){
		BankingDAOServicesImpl.customer.clear();
		BankingDAOServicesImpl.CUSTOMER_ID_COUNTER = 1000;
	}

	@AfterClass
	public static void tearDownBankingServices(){
		bankServices= null;
	}

}
