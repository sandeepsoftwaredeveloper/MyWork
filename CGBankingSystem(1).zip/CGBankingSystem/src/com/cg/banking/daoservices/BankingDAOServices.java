package com.cg.banking.daoservices;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
public interface BankingDAOServices {
	int insertCustomer(Customer customer);
	int insertAccount(Account account);
	int generatePin(Account account);
	boolean updateAccount(int customerId,Account account);
	boolean insertTransaction(int customerId,int accountNo,Transaction transaction);
	boolean deleteCustomer(int customerId);
	boolean deleteAccount(int customerId,int accountNo);
	Customer getCustomer(int customerId);
	Account getAccount(int customerId,int accountNo);
	List<Customer> getCustomers();
	List<Account> getAccounts(int customerId);
	List<Transaction> getTransaction(int accountNo);
	
}
