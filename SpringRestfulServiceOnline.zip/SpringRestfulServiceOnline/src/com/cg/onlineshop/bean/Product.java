package com.cg.onlineshop.bean;

public class Product {
private int productCode,productPrice;
private String productDescription,productName;
public int getProductCode() {
	return productCode;
}
public void setProductCode(int productCode) {
	this.productCode = productCode;
}
public int getProductPrice() {
	return productPrice;
}
public void setProductPrice(int productPrice) {
	this.productPrice = productPrice;
}
public String getProductDescription() {
	return productDescription;
}
public void setProductDescription(String productDescription) {
	this.productDescription = productDescription;
}
public String getProductName() {
	return productName;
}
public void setProductName(String productName) {
	this.productName = productName;
}
public Product(int productCode, int productPrice, String productDescription,
		String productName) {
	super();
	this.productCode = productCode;
	this.productPrice = productPrice;
	this.productDescription = productDescription;
	this.productName = productName;
}
public Product() {
	super();
	// TODO Auto-generated constructor stub
}

}
