package com.cg.onlineshop.controllers;

import java.util.ArrayList;
import java.util.Hashtable;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.onlineshop.bean.Product;
import com.cg.onlineshop.bean.ProductList;
import com.cg.onlineshop.exception.ProductDetailsNotFoundException;
@RestController
public class ProductCatlogaServicesController {
	private static Hashtable<Integer,Product>productsMap;
	static{
		productsMap=new Hashtable<>();
		productsMap.put(111,new Product(111,120000,"ABC","Pen"));
		productsMap.put(112,new Product(112,120000,"HPThinkPad","Laptop"));
		productsMap.put(113,new Product(113,50000,"Touchscreen","mobile"));
		
	}
	public ProductCatlogaServicesController(){
		System.out.println("ProductCatlogServicesController");
	}
	@RequestMapping(value={"/SayHello"},produces={"application/text"})
	public ResponseEntity<String> getHelloMessage(){
		ResponseEntity<String>responseEntity=new ResponseEntity<String>("hello World FromRestfulWebServices",HttpStatus.OK);
		return responseEntity;
	}

	@RequestMapping(value={"/allProductDetailsJSON"},headers="Accept=application/json")
	
	public ResponseEntity<ArrayList<Product>> getAllProductDetailsJSON(){
		ArrayList<Product> productList=new ArrayList<>(productsMap.values());
			return	new ResponseEntity<>(productList,HttpStatus.OK);
	}
	
	
	@RequestMapping(value={"/productDetailsPathParam/{productCode}"},headers="Accept=application/json")
	public ResponseEntity<Product> getProductDetailsPathVariable(@PathVariable("productCode") int productCode){
		Product product= productsMap.get(productCode);
			return	new ResponseEntity<>(product,HttpStatus.OK);
		
	
	}

	@RequestMapping(value={"/allProductDetailsXML"},produces=MediaType.APPLICATION_XML_VALUE)
	public ResponseEntity<ProductList> getAllProductDetailsXML(){
		
		
		
		ProductList productList=new ProductList(new ArrayList<>(productsMap.values()));
		return new ResponseEntity<>(productList,HttpStatus.OK);
		
		
		
	
	
}
	@RequestMapping(value={"/productDetailsRequestParam"},produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
				
				public ResponseEntity<Product> getProductDetailsRequestParam(@RequestParam("productCode") int productCode)
						throws ProductDetailsNotFoundException{
					Product product= productsMap.get(productCode);
					if(product==null)throw new ProductDetailsNotFoundException("product details with productCode"+productCode+"not found");
						return	new ResponseEntity<>(product,HttpStatus.OK);
						
			}
	

	@RequestMapping(value = { "/productDetailsPathVariable/{productCode}" }, produces = MediaType.APPLICATION_JSON_VALUE, headers = "Accept= application/json")
		public ResponseEntity<Product> getAllProductDetailsPathVariable(
				@PathVariable("productCode") int productCode) throws ProductDetailsNotFoundException {
			Product product = productsMap.get(productCode);
			if (product == null)
				throw new ProductDetailsNotFoundException(
						"Product details with code: " + productCode + " not found!");
			return new ResponseEntity<>(product, HttpStatus.OK);

		} 

		@RequestMapping(value="/acceptProductDetails",method=RequestMethod.POST,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
		public ResponseEntity<String> acceptProductDetails(@ModelAttribute Product product){
			productsMap.put(product.getProductCode(), product);
			return new ResponseEntity<>("Product details successfully added", HttpStatus.OK);
		}

		@RequestMapping(value="/deleteProductDetails/{productCode}",method=RequestMethod.DELETE,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
		public ResponseEntity<String>deleteProductDetails(@PathVariable("productCode")int productCode) throws ProductDetailsNotFoundException{
			Product product = productsMap.remove(productCode);
			if(product==null)throw new ProductDetailsNotFoundException("Product details with product code" +productCode+"not found");
			return new ResponseEntity<>("Product Details With ProductCode"+productCode +"Successfully deleted", HttpStatus.OK);

		} 

		
		
			@RequestMapping(value="/addProductDetailsBulkJSON", method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_JSON_VALUE)
			 public ResponseEntity<String> addProductDetailsBulkJSON(@RequestBody ArrayList<Product> products)
			 {
				 for(Product product:products)
					 productsMap.put(product.getProductCode(), product);
				 return new ResponseEntity<>("Product Details Successfully added",HttpStatus.OK);
			 } 
		

	
	


	
	
}

