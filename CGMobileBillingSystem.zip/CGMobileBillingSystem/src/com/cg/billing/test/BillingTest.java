package com.cg.billing.test;
import static org.junit.Assert.*;

import java.sql.SQLException;

import javax.xml.ws.BindingType;

import org.junit.Before;
import org.junit.BeforeClass;






import org.junit.Test;





import com.cg.mobilebilling.beans.Address;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.BillingDAOServicesImpl;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;
import com.cg.mobilebilling.services.BillingServicesImpl;

public class BillingTest {
	private static BillingServices billingServices;
	@BeforeClass
	public static void setUpBillingServices(){
		billingServices = new BillingServicesImpl();

}

//	@Before
//	public void setUpTestData(){
	//	BillingDAOServicesImpl.customer.put(1000, new Customer(1000,"satish","mahajan","sm@capgi.com",25/11/1993","ABCD1234",new Address("Patiala", "Punjab",147001)new PostpaidAccount(981234575,"postpaid" new Bill (101,50,40,11,20,22,11,1000,100,500,1000,1500,400,11,12)));
//	}
	
	@Before
	public void setUpBillingData() throws SQLException{
		
		Customer customer1= new Customer(1001, "Shubham", "Gupta", "shubham.gupta@capgemini.com", "1-JAN-1993", "password", new Address("lakhimpur", "UP", 262708), new PostpaidAccount(98740, new Plan(1, 299, 300, 300, 200, 200, 1024, 1, 1, 1, 2, 2, "PUNE", "Basic"), new Bill(101, 51, 25, 360, 200, 2400, "June", 1200, 50, 60, 305, 120, 560, 154, 52) ));
		Customer customer2= new Customer(1002, "Arpit", "Gupta", "arpit.gupta@capgemini.com", "11-JUL-1994", "password1", new Address("kanpur", "UP", 262455), new PostpaidAccount(98789, new Plan(2, 989, 200, 100, 400, 500, 2024, 2, 3, 4, 1, 2, "MUMBAI", "Basic"), new Bill(102, 52, 26, 361, 201, 3400, "July", 1201, 60, 70, 300, 121, 561, 155, 58) ));
		Customer customer3= new Customer(1003, "Neeraj", "Gupta", "neeraj.gupta@capgemini.com", "17-FEB-1994", "password2", new Address("lucknowr", "UP", 211008), new PostpaidAccount(78740, new Plan(3, 289, 300, 300, 200, 200, 1024, 2, 4, 1, 1, 3, "HYDERABAD", "Basic"), new Bill(103, 52, 27, 362, 203, 3400, "August", 1202, 70, 80, 301, 122, 562, 156, 55)));
	}
	
	@Test(expected=CustomerDetailsNotFoundException.class)
	public void testopenPostpaidAccountforInvalidCustomerId()throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		billingServices.openPostpaidMobileAccount(1111, 1);
	}
	
	@Test
	public void testopenPostpaidAccountforValidCustomerId()throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		long expectedCustomer = 1001L;
		long actualCustomer= billingServices.openPostpaidMobileAccount(1001, 1);
	assertEquals(expectedCustomer,actualCustomer);
	}

	@Test(expected=CustomerDetailsNotFoundException.class)
	public void testopenPostpaidAccountforInvalidPlanId()throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		billingServices.openPostpaidMobileAccount(1001, 7);
	}
	
	@Test
	public void testopenPostpaidAccountforValidPlanId()throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		long expectedCustomer = 1;
		long actualCustomer= billingServices.openPostpaidMobileAccount(1001, 1);
	assertEquals(expectedCustomer,actualCustomer);
	}
	
	@Test(expected=CustomerDetailsNotFoundException.class)
	public void testgeneratemonthlymobilebillforInvalidCustomerId()throws  CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
	BillingServicesDownException, PlanDetailsNotFoundException{
		billingServices.generateMonthlyMobileBill(2222, 98740, "JAN", 51, 25, 360, 200,2400 );
	}
	
	@Test
	public void testgeneratemonthlymobilebillforValidCustomerId()throws  CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
	BillingServicesDownException, PlanDetailsNotFoundException{
		Double expectedCustomerId =1001D;
		Double actualCustomerId=billingServices.generateMonthlyMobileBill(1001, 98740, "JAN", 51, 25, 360, 200,2400 );
		assertEquals(expectedCustomerId,actualCustomerId);
	}
	
	@Test(expected=CustomerDetailsNotFoundException.class)
	public void testgeneratemonthlymobilebillforInvalidMobileNo()throws  CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
	BillingServicesDownException, PlanDetailsNotFoundException{
		billingServices.generateMonthlyMobileBill(2222, 985543, "JAN", 51, 25, 360, 200,2400 );
	}
	
	@Test
	public void testgeneratemonthlymobilebillforValidMobileNo()throws  CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
	BillingServicesDownException, PlanDetailsNotFoundException{
		Double expectedMobileNo =98740D;
		Double actualMobileNo=billingServices.generateMonthlyMobileBill(1001, 98740, "JAN", 51, 25, 360, 200,2400 );
	assertEquals(expectedMobileNo, actualMobileNo);
	}
	
	@Test(expected=InvalidBillMonthException.class)
	public void testgeneratemonthlymobilebillforInvalidMonth()throws  CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
	BillingServicesDownException, PlanDetailsNotFoundException{
		billingServices.generateMonthlyMobileBill(1001, 98740, "ABC", 51, 25, 360, 200,2400);
	}
	public void testgeneratemonthlymobilebillforValidMonth()throws  CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
	BillingServicesDownException, PlanDetailsNotFoundException{
		Double expectedMonth=656D;
		Double actualMonth=billingServices.generateMonthlyMobileBill(1001, 98740, "JAN", 51, 25, 360, 200,2400);
		assertEquals(expectedMonth,actualMonth);
	}
	@Test(expected=CustomerDetailsNotFoundException.class)
	public void testgetCustomerDetailsforInvalidCustomerId() throws CustomerDetailsNotFoundException, BillingServicesDownException{
		billingServices.getCustomerDetails(1111);
	}
	
	public void testgetCustomerDetailsforValidCustomerId() throws CustomerDetailsNotFoundException, BillingServicesDownException{
	Customer expectedCustomer=new Customer(1001, "Shubham", "Gupta", "shubham.gupta@capgemini.com", "1-JAN-1993", "password", new Address("lakhimpur", "UP", 262708), new PostpaidAccount(98740, new Plan(1, 299, 300, 300, 200, 200, 1024, 1, 1, 1, 2, 2, "PUNE", "Basic"), new Bill(101, 51, 25, 360, 200, 2400, "June", 1200, 50, 60, 305, 120, 560, 154, 52) ));
	Customer actualCustomer=billingServices.getCustomerDetails(1001);
	assertEquals(expectedCustomer,actualCustomer);
	
	
}
	
	@Test(expected=PostpaidAccountNotFoundException.class)
	public void testgetPostPaidAccountDetailsforInvalidCustomerId() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		billingServices.getPostPaidAccountDetails(1111,98740);
	}
	public void testgetPostPaidAccountDetailsforvalidCustomerId() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
	
	PostpaidAccount expectedDetails=new PostpaidAccount(98740, new Plan(1, 299, 300, 300, 200, 200, 1024, 1, 1, 1, 2, 2, "PUNE", "Basic"), new Bill(101, 51, 25, 360, 200, 2400, "June", 1200, 50, 60, 305, 120, 560, 154, 52));
	PostpaidAccount actualDetails= billingServices.getPostPaidAccountDetails(1001, 98740);
	assertEquals( expectedDetails,actualDetails);
	}
	@Test(expected=PostpaidAccountNotFoundException.class)
	public void testgetPostPaidAccountDetailsforInvalidMobileNo() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		billingServices.getPostPaidAccountDetails(1001,98741);
	}
	public void testgetPostPaidAccountDetailsforvalidMobileNo() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		
		PostpaidAccount expectedDetails=new PostpaidAccount(98740, new Plan(1, 299, 300, 300, 200, 200, 1024, 1, 1, 1, 2, 2, "PUNE", "Basic"), new Bill(101, 51, 25, 360, 200, 2400, "June", 1200, 50, 60, 305, 120, 560, 154, 52));
		PostpaidAccount actualDetails= billingServices.getPostPaidAccountDetails(1001, 98740);
		assertEquals( expectedDetails,actualDetails);
		}
	
	
	@Test(expected=BillDetailsNotFoundException.class)
	public void testgetMobileBillDetailsforInvalidCustomerId() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
	BillDetailsNotFoundException, BillingServicesDownException {
		billingServices.getMobileBillDetails(1000, 98740, "JAN");
	}
	public void testgetMobileBillDetailsforValidCustomerId() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
	BillDetailsNotFoundException, BillingServicesDownException {
		Bill expectedDetails=new Bill(101, 51, 25, 360, 200, 2400, "June", 1200, 50, 60, 305, 120, 560, 154, 52);
		Bill actualDetails=billingServices.getMobileBillDetails(1001, 98740, "JAN");
		assertEquals(expectedDetails, actualDetails);
	}

	@Test(expected=BillDetailsNotFoundException.class)
	public void testgetMobileBillDetailsforInvalidMobileNo() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
	BillDetailsNotFoundException, BillingServicesDownException {
		billingServices.getMobileBillDetails(1001, 9874, "JAN");
	}
	public void testgetMobileBillDetailsforValidMobileNo() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
	BillDetailsNotFoundException, BillingServicesDownException {
		Bill expectedDetails=new Bill(101, 51, 25, 360, 200, 2400, "June", 1200, 50, 60, 305, 120, 560, 154, 52);
		Bill actualDetails=billingServices.getMobileBillDetails(1001, 98740, "JAN");
		assertEquals(expectedDetails, actualDetails);
	}
	
	@Test(expected=BillDetailsNotFoundException.class)
	public void testgetMobileBillDetailsforInvalidBillMonth() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
	BillDetailsNotFoundException, BillingServicesDownException {
		billingServices.getMobileBillDetails(1001, 98740, "FEB");
	}
	@Test
	public void testgetMobileBillDetailsforValidInvalidBillMonth() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
	BillDetailsNotFoundException, BillingServicesDownException {
		Bill expectedDetails=new Bill(101, 51, 25, 360, 200, 2400, "June", 1200, 50, 60, 305, 120, 560, 154, 52);
		Bill actualDetails=billingServices.getMobileBillDetails(1001, 98740, "JAN");
		assertEquals(expectedDetails, actualDetails);
	}
	
	@Test(expected=PostpaidAccountNotFoundException.class)
	public void testcloseCustomerPostPaidAccountforInvalidCustomerId() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		billingServices.closeCustomerPostPaidAccount(1000, 98740);
	}
	public void testcloseCustomerPostPaidAccountforValidCustomerId() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		boolean expectedDetails=true;
		boolean actualDetails=billingServices.closeCustomerPostPaidAccount(1001, 98740);
		assertEquals(expectedDetails,actualDetails);
	}
	
	@Test(expected=PostpaidAccountNotFoundException.class)
	public void testcloseCustomerPostPaidAccountforInvalidMobileNo() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		billingServices.closeCustomerPostPaidAccount(1001, 98749);
	}
	public void testcloseCustomerPostPaidAccountforValidMobileNo() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		boolean expectedDetails=true;
		boolean actualDetails=billingServices.closeCustomerPostPaidAccount(1001, 98740);
		assertEquals(expectedDetails,actualDetails);
	}
	
	@Test(expected=CustomerDetailsNotFoundException.class)
	public void testdeleteCustomerforInvalidMobileNo() throws BillingServicesDownException, CustomerDetailsNotFoundException {
		billingServices.deleteCustomer(1000);
	}
	public void testdeleteCustomerforValidMobileNo() throws BillingServicesDownException, CustomerDetailsNotFoundException {
		boolean expectedDetails=true;
		boolean actualDetails=billingServices.deleteCustomer(1001);
		assertEquals(expectedDetails,actualDetails);
	}
	
	@Test(expected=PostpaidAccountNotFoundException.class)
	public void testgetCustomerPostPaidAccountPlanDetailsforInvalidCustomerId() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
	PlanDetailsNotFoundException {
		billingServices.getCustomerPostPaidAccountPlanDetails(1000, 98740);
	}
	public void testgetCustomerPostPaidAccountPlanDetailsforValidCustomerId() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
	PlanDetailsNotFoundException {
		Plan expectedDetails=new Plan(1, 299, 300, 300, 200, 200, 1024, 1, 1, 1, 2, 2, "PUNE", "Basic");
		Plan actualDetails=billingServices.getCustomerPostPaidAccountPlanDetails(1001,98740);
		assertEquals(expectedDetails,actualDetails);
	}
	@Test(expected=PostpaidAccountNotFoundException.class)
	public void testgetCustomerPostPaidAccountPlanDetailsforInvalidMobileNo() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
	PlanDetailsNotFoundException {
		billingServices.getCustomerPostPaidAccountPlanDetails(1001, 9874);
	}
	public void testgetCustomerPostPaidAccountPlanDetailsforValidNobileNo() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
	PlanDetailsNotFoundException {
		Plan expectedDetails=new Plan(1, 299, 300, 300, 200, 200, 1024, 1, 1, 1, 2, 2, "PUNE", "Basic");
		Plan actualDetails=billingServices.getCustomerPostPaidAccountPlanDetails(1001,98740);
		assertEquals(expectedDetails,actualDetails);
	}
	
	
}
	

	
	
	
	
	
	








	
	
	
	
	
	