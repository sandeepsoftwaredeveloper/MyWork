package com.cg.mobilebilling.beans;

import java.util.HashMap;
import java.util.Map;
public class PostpaidAccount {
	private long mobileNo;
	private Plan plan;
	public PostpaidAccount() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PostpaidAccount(long mobileNo, Plan plan, Map<Integer, Bill> bills) {
		super();
		this.mobileNo = mobileNo;
		this.plan = plan;
		this.bills = bills;
	}
	public PostpaidAccount(int i, Plan plan2, Bill bill) {
		// TODO Auto-generated constructor stub
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public Plan getPlan() {
		return plan;
	}
	public void setPlan(Plan plan) {
		this.plan = plan;
	}
	public Map<Integer, Bill> getBills() {
		return bills;
	}
	public void setBills(Map<Integer, Bill> bills) {
		this.bills = bills;
	}
	private Map<Integer, Bill> bills = new HashMap<>();
}